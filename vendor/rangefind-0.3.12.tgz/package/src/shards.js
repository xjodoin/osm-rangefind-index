export const RANGE_MERGE_GAP_BYTES = 8 * 1024;

export function shardKey(term, depth) {
  // Do not pad short terms: "ai" padded to "ai_" collides with a real
  // underscore-bearing expansion term. Variable-length directory keys are
  // already supported and keep every partition address unique.
  const value = String(term || "");
  let end = Math.min(value.length, Math.max(0, Math.floor(Number(depth) || 0)));
  // JavaScript slice offsets are UTF-16 code units. Never leave a high
  // surrogate at the end of a physical shard name: UTF-8 encoders replace
  // that unpaired code unit, changing both its persisted value and sort order.
  if (
    end > 0
    && end < value.length
    && value.charCodeAt(end - 1) >= 0xd800
    && value.charCodeAt(end - 1) <= 0xdbff
    && value.charCodeAt(end) >= 0xdc00
    && value.charCodeAt(end) <= 0xdfff
  ) {
    end++;
  }
  return value.slice(0, end);
}

export function baseShardFor(term, config) {
  return shardKey(term, config.baseShardDepth);
}

export function entryPostingCount(entries) {
  return entries.reduce((sum, [, rows]) => sum + rows.length, 0);
}

export function partitionEntries(entries, config, depth = config.baseShardDepth) {
  if (!entries.length) return [];
  if (entryPostingCount(entries) <= config.targetShardPostings || depth >= config.maxShardDepth) {
    return [{ name: shardKey(entries[0][0], depth), entries }];
  }
  const groups = new Map();
  for (const entry of entries) {
    const key = shardKey(entry[0], depth + 1);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(entry);
  }
  return [...groups.entries()]
    // Code-unit order to match compareDirectoryKeys; localeCompare breaks
    // the directory's binary-search invariant for non-ASCII shard keys.
    .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0))
    .flatMap(([, group]) => partitionEntries(group, config, depth + 1));
}

export function groupRanges(items, options = RANGE_MERGE_GAP_BYTES) {
  const mergeGapBytes = typeof options === "number" ? options : options.mergeGapBytes ?? RANGE_MERGE_GAP_BYTES;
  const maxMergedBytes = typeof options === "number" ? Infinity : options.maxMergedBytes ?? Infinity;
  const maxOverfetchBytes = typeof options === "number" ? Infinity : options.maxOverfetchBytes ?? Infinity;
  const maxOverfetchRatio = typeof options === "number" ? Infinity : options.maxOverfetchRatio ?? Infinity;
  const byPack = new Map();
  for (const item of items) {
    if (!byPack.has(item.entry.pack)) byPack.set(item.entry.pack, []);
    byPack.get(item.entry.pack).push(item);
  }
  const groups = [];
  for (const [pack, packItems] of byPack) {
    const sorted = packItems
      .map(item => ({ ...item, start: item.entry.offset, end: item.entry.offset + item.entry.length }))
      .sort((a, b) => a.start - b.start);
    let current = null;
    for (const item of sorted) {
      const itemBytes = item.end - item.start;
      if (!current) {
        current = { pack, start: item.start, end: item.end, items: [item] };
        Object.defineProperty(current, "exactBytes", { value: itemBytes, writable: true, enumerable: false });
        groups.push(current);
        continue;
      }
      const nextEnd = Math.max(current.end, item.end);
      const mergedBytes = nextEnd - current.start;
      const exactBytes = current.exactBytes + itemBytes;
      const overfetchBytes = mergedBytes - exactBytes;
      const shouldMerge = item.start <= current.end + mergeGapBytes
        && mergedBytes <= maxMergedBytes
        && overfetchBytes <= maxOverfetchBytes
        && mergedBytes <= exactBytes * maxOverfetchRatio;
      if (!shouldMerge) {
        current = { pack, start: item.start, end: item.end, items: [item] };
        Object.defineProperty(current, "exactBytes", { value: itemBytes, writable: true, enumerable: false });
        groups.push(current);
      } else {
        current.items.push(item);
        current.end = nextEnd;
        current.exactBytes = exactBytes;
      }
    }
  }
  return groups;
}
