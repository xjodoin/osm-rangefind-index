# French Wikipedia Scalability Fixture

Rangefind includes a reproducible scalability fixture for French Wikipedia.
The fixture streams the official Wikimedia article dump, converts pages to
JSONL, builds a static Rangefind index, writes a small browser search site, and
records a local request/transfer benchmark with cold-transfer breakdowns for
directory, term, posting-block, main-index typo correction, doc-value, sorted
doc-value, packed document payload, and doc-page payload fetches.
The generated schema includes multi-value article tags, typed numeric fields,
revision dates, and booleans so the scalability run also validates the typed
filter/sort code paths.

## Data Source

Default dump:

```text
https://dumps.wikimedia.org/frwiki/latest/frwiki-latest-pages-articles.xml.bz2
```

The current `frwiki/latest` index listed this file as a multi-gigabyte
compressed article dump. The fixture reads it as a stream, so bounded samples do
not require downloading the full archive first.

The runner shells out to `curl` and the decompressor matching the dump extension
(`bzip2` for the default `.bz2` input, `gzip` for `.gz` inputs).

## Commands

Build and benchmark a bounded sample:

```bash
npm run build:browser
node scripts/frwiki_fixture.mjs all --limit=5000
```

Rerun only the runtime benchmark against the existing generated index:

```bash
node scripts/frwiki_fixture.mjs runtime-bench --limit=5000 --runs=3
# or keep the all command shape and skip extraction/build:
node scripts/frwiki_fixture.mjs all --limit=5000 --runs=3 --reuse-index
```

Run only the builder benchmark and skip runtime queries:

```bash
node scripts/frwiki_fixture.mjs builder-bench --limit=5000
# or keep the all command shape and stop after the build report:
node scripts/frwiki_fixture.mjs all --limit=5000 --builder-only
```

Run against the full dump:

```bash
node scripts/frwiki_fixture.mjs all --limit=0
```

Serve the generated site:

```bash
node scripts/serve.mjs examples/frwiki/public 5180
```

Useful options:

- `--body-chars=N`: indexes only the first `N` cleaned article characters.
  Default: `6000`. Use `0` for uncapped article text.
- `--dump-url=URL_OR_FILE`: reads another dump URL or local dump file.
- `--force`: regenerates JSONL even when the existing metadata matches the
  requested dump URL, limit, and body cap, and refreshes the reusable extracted
  JSONL cache.
- `--reuse-index`: skips JSONL extraction, site generation, and index building.
  Use this for runtime-only changes when `public/rangefind` already matches the
  requested limit.
- `--builder-only`: builds the index and writes the builder report while
  skipping runtime query rows. Use this when the change affects only indexing.
- `--build-progress-ms=N`: controls live builder progress logging. The frwiki
  fixture defaults to `15000`, so long builds print phase heartbeats with
  elapsed time, RSS, heap, temp bytes, pack bytes, and sidecar bytes.
- `--queries=a|b|c`: overrides benchmark queries.
- `--scale-limits=50000,100000`: controls the `scale` command document counts.
- `--no-exact-checks`: skips the exact top-k comparison for text queries.

The fixture keeps a source-data cache at `data/frwiki.cache.jsonl` with matching
metadata. Once a larger limit has been extracted, later smaller or equal limits
with the same dump URL and `--body-chars` are materialized by slicing that cache
instead of streaming and decompressing the Wikimedia dump again.

## Benchmark Coverage

The `bench` command now exercises a broader set of cold-query lanes instead of
only the default text queries. Each row records a `category`, the full request
shape, cold request/KB breakdowns, compact runtime stats, validation status, and
exact top-k agreement where an exact comparison is meaningful.

Every benchmark run writes into repo-level `benchmarks/frwiki/` instead of
overwriting flat JSON files in the fixture root or mixing generated history into
`examples/`. The layout keeps both latest results and historical raw reports:

```text
benchmarks/frwiki/
  latest/
    runtime/limit-50000.json
    builder/limit-50000.json
    scale/full-dump.json
  history/
    runtime/limit-50000/<timestamp>_<commit>.json
    builder/limit-50000/<timestamp>_<commit>.json
    scale/full-dump/<timestamp>_<commit>.json
  index.json
```

`index.json` is a compact progression ledger. It stores one summary per run,
the current latest report for each `kind:limit` pair, and numeric deltas against
the previous run with the same kind and limit so regressions can be inspected
without opening every raw report. The `benchmarks/frwiki/` tree is tracked by
git so benchmark progression and regressions are visible in normal code review.

The builder report uses `rfbuilderbench-v1` and records phase wall time, peak
RSS, heap samples, temp bytes, output bytes, worker summaries, and write
amplification. Full runtime reports embed the latest builder report under the
top-level `builder` key, and `scale --builder-only` records builder-only scale
points without spending time on query execution.

Covered scenarios include:

- default text queries from `--queries`
- query-bundle phrase retrieval and page-2 pagination
- larger top-k windows
- zero-result exact queries
- typo recovery cases
- filtered text queries
- text sorted by typed doc values
- rerank-disabled text retrieval
- numeric/date browse filters
- sorted doc-value browse
- facet-only browse
- facet + boolean + numeric sorted browse

Rows with typo correction or external sort can skip exact top-k comparison when
the exact exhaustive scorer is not the same final behavior being measured, but
they still validate expected result counts, selected filters, sort order, and
runtime-lane flags.

The external quality comparison builds local Lucene and Tantivy BM25 indexes
over the same JSONL fixture and compares known-title and typo judgments against
Rangefind:

```bash
npm run bench:frwiki:quality -- --root=/tmp/rangefind-frwiki-500k-current
```

The report is written to `benchmarks/frwiki/latest/quality/`. It contains
Rangefind rows plus Lucene and Tantivy OR, AND, and exact-title-boosted rows
with Hit@1/Hit@3/Hit@10/MRR@10 metrics. Tantivy also records a bounded
title-fuzzy profile as a search-engine fuzzy anchor. Install the Rust toolchain
with Homebrew when the local machine does not already have `cargo`.

Latest 500k quality run with main-index typo correction:

```text
Rangefind known titles:       Hit@10 200/200, MRR@10 0.994
Rangefind typo judgments:     Hit@10 135/200, MRR@10 0.640
Removed sidecar baseline:     Hit@10 133/200, MRR@10 0.618
Lucene title-boost typo:      Hit@10 114/200, MRR@10 0.451
Tantivy title-fuzzy typo:     Hit@10 137/200, MRR@10 0.501
Guard false corrections:      0/50
Typo runtime caps observed:   max 3 corrected searches, max 12 shard lookups
```

Typo correction now derives candidates from the main term directory and validates
corrected plans through normal postings. The quality harness keeps the removed
delete-key sidecar baseline as a recorded artifact only, so Hit@10/MRR parity is
visible without shipping `typo/` packs in the final index.

Rangefind also has a compatibility harness for Quickwit's
`search-benchmark-game` protocol:

```bash
npm run bench:frwiki:search-game
```

The harness reads the existing frwiki fixture, generates phrase/union/intersection
query rows, runs the top-k Search Benchmark Game command shapes (`TOP_10`,
`TOP_100`, and `TOP_1000` by default), and writes reports under:

```text
benchmarks/frwiki/latest/search-benchmark-game/
benchmarks/frwiki/history/search-benchmark-game/
```

You can point it at an upstream checkout's query file and published result file
when you want overlap rows against the official benchmark data:

```bash
npm run bench:frwiki:search-game -- \
  --queries=/path/to/search-benchmark-game/queries.txt \
  --upstream-results=/path/to/search-benchmark-game/results.json
```

This is intentionally a protocol-compatible local trend benchmark, not an
official Search Benchmark Game submission. Rangefind is measured through its
browser/static-index runtime over local HTTP range requests. `COUNT` and
`TOP_K_COUNT` return exact totals for Rangefind-normalized query semantics
through a postings-only count path. Lucene query syntax such as `+term` and
quoted phrases is normalized to Rangefind query text while retaining the
original tags in the report, so count deltas against published engines are
reported as semantic deltas unless they disagree with Rangefind exact search.

Use the replay profiler when optimizing the upstream query path. It keeps the
run single-process so Node CPU profiles line up with the per-query trace rows:

```bash
node --cpu-prof \
  --cpu-prof-dir=benchmarks/frwiki/latest/search-benchmark-game \
  --cpu-prof-name=search-game-profile.cpuprofile \
  scripts/search_benchmark_game_profile.mjs \
  --queries=/tmp/search-benchmark-game/queries.txt \
  --index=/tmp/search-benchmark-game/engines/rangefind/index/public/rangefind \
  --commands=COUNT,TOP_100_COUNT \
  --query-limit=50 \
  --runs=1 \
  --warmup-runs=1 \
  --cpu-profile-path=benchmarks/frwiki/latest/search-benchmark-game/search-game-profile.cpuprofile
```

For an upstream Search Benchmark Game checkout, the repo also includes an engine
adapter in `scripts/search_benchmark_game/rangefind/`. Symlink or copy that
directory into the upstream checkout's `engines/rangefind` directory, set
`RANGEFIND_REPO=/path/to/rangefind` when needed, and run the normal upstream
flow with `ENGINES=rangefind COMMANDS="TOP_10 TOP_100 TOP_1000"`. The adapter
implements the expected `clean`, `compile`, `index`, and `serve` targets. Its
`index` target preserves the builder resume directory unless
`RANGEFIND_SBG_FORCE=1` is set. The upstream adapter opts into `size=1000`
top-k proof planning, disables dependency rerank and document hydration for
protocol timing, uses a 2048 posting-block budget for pathological broad
queries, and serves `COUNT`, `UNOPTIMIZED_COUNT`, and `TOP_K_COUNT` with the
exact Rangefind-normalized postings-only count path.

Latest COUNT replay profile against the full upstream 5,032,104-document index
at `/tmp/search-benchmark-game/engines/rangefind/index/public/rangefind`,
using commit `a75cb8c-dirty` and saving
`benchmarks/frwiki/latest/search-benchmark-game/search-game-count-profile.cpuprofile`:

```text
COUNT:         best mean  3.42 ms, p50  3.21 ms, p90  4.08 ms
TOP_100_COUNT: best mean 42.30 ms, p50 45.55 ms, p90 75.73 ms
```

Latest upstream COUNT run with `WARMUP_TIME=1`, `NUM_ITER=1`, and
`COMMANDS="COUNT TOP_10_COUNT TOP_100_COUNT TOP_1000_COUNT"` over all 962
official queries:

```text
COUNT:          mean  9.14 ms, p50  3.18 ms, p90  4.94 ms
TOP_10_COUNT:   mean 45.47 ms, p50 48.22 ms, p90 74.98 ms
TOP_100_COUNT:  mean 48.11 ms, p50 51.26 ms, p90 81.08 ms
TOP_1000_COUNT: mean 46.40 ms, p50 48.51 ms, p90 77.78 ms
```

Rangefind count outputs are internally consistent across `COUNT` and
`TOP_K_COUNT` for all 962 official queries. Against published
Search Benchmark Game count outputs, only 54/962 rows match Tantivy/Lucene
exactly because this pass counts Rangefind-normalized semantics: stopwords such
as `the` count as `0`, quoted phrases are not phrase-counted, and bare multi-term
queries use Rangefind's current base-term eligibility.

Latest upstream top-k run with one warmup pass and one measured pass over all
962 official queries:

```text
TOP_10:   mean 46.38 ms, p50 49.74 ms, p90 79.56 ms
TOP_100:  mean 47.25 ms, p50 51.00 ms, p90 82.03 ms
TOP_1000: mean 44.65 ms, p50 47.54 ms, p90 76.90 ms
```

The known-title improvement still comes from a generic authority sidecar over
configured label fields, not from Wikipedia-specific rules. The runtime probes a
diacritic-preserving surface key first, so `Paris`, `Médecine`, `Victor Hugo`,
and `Québec` rank above homonymy/partial-title pages. Query bundles still
short-circuit exact phrase queries such as `changement climatique` without
touching authority.

Latest 500k cold-query rows after authority sharding:

```text
Paris:                  Paris,        40 requests, 176.1 KB, authority 34.0 KB
Médecine:               Médecine,     26 requests, 171.2 KB, authority 18.3 KB
Victor Hugo:            Victor Hugo,  37 requests, 289.3 KB, authority  6.2 KB
Québec:                 Québec,       28 requests, 212.1 KB, authority 18.0 KB
changement climatique:  unchanged,    28 requests,  76.8 KB, authority skipped
fromage:                unchanged,    19 requests, 239.5 KB, authority miss 9.6 KB
```

An older full 500k build took 3,642 seconds wall time with the removed
base-shard worker reducer and peaked at about 2.39 GB RSS. The old delete-key
typo-sidecar merge/reduction path has since been removed; typo correction is now
bounded at query time by main term-shard probes and corrected search plans.

Newer indexes include `manifest.build` (`rfbuildtelemetry-v1`) with phase
timings, peak RSS, selected-term spool bytes, raw document spool bytes, and
compressed document spool bytes. Use those manifest counters alongside
`/usr/bin/time` when comparing builder changes, because they identify whether a
run moved time between ingestion, posting reduction, query bundles, typo
candidate planning, document packs, and doc pages.

Latest recorded scale run with main-index typo correction and doc-id document
pointers:

```text
100k: build 78.9s, 297.1 MiB published index, 0/25 invalid runtime rows
500k: build 368.5s, 1385.4 MiB published index, 0/25 invalid runtime rows
```

After moving scan-document work into worker threads (JSONL parse, analysis,
payload gzip, spool encoding, per-worker posting segments), keeping one open
file descriptor per pack with incremental content hashing, compressing
doc-page/rank-map objects in a worker pool, reducing sort-replica partitions
through the partition worker pool, and scaling worker counts to machine
parallelism, the same fixture builds:

```text
100k: build  24.1s (was 78.9s), 0/25 invalid runtime rows, exact top-k 16/16
500k: build 115.6s (was 368.5s), 0/25 invalid runtime rows, exact top-k 16/16
```

Cold-query transfer stayed inside the previous baselines at both scales
(500k average 118.1 ms, 29.7 requests, 327.0 KB versus the previous
118.8 ms / 29.6 requests / 327.0 KB), so the indexing speedup does not change
runtime retrieval behavior.

A 1,000,000-document fixture built in 206.2s at 4.80 GiB peak RSS (an older
recorded 1M run took 4,276.5s), producing a 1,876 MiB published index with
0/25 invalid runtime rows and 16/16 exact top-k agreement.

## Full French Wikipedia

The complete `frwiki/latest` article dump (2,753,081 articles from 5,981,193
dump pages) now builds and queries end to end:

```text
Docs indexed:   2,753,081
Clean build:    628.5s wall (10.5 minutes) from cached JSONL
Peak RSS:       4.36 GiB
Published:      4.92 GiB, 1,658 files, 1,920 B/doc
Runtime rows:   25/25 valid, exact top-k 16/16
Cold queries:   123.3 ms avg, 46.9 requests, 969.7 KB avg transfer
```

Three multi-million-document cliffs had to be removed to get there:

- Partition reduce workers thrashed the chunked code-store cache once the
  corpus outgrew 64 cached chunks (about 1M docs), making reduce-postings
  superlinear (30+ minutes before being aborted). Doc-value files are now
  preloaded into SharedArrayBuffers shared across reduce workers
  (`codeStoreWorkerPreloadMaxBytes`), which brought the phase to 85s.
- The same cache thrash hit sorted doc-value page summaries on the main
  thread (951.8s); the main code store now preloads after posting reduction
  (`codeStorePreloadMaxBytes`), bringing doc-value-sorted to 9.9s.
- Authority base shards that split an astral code point produced lone
  surrogates that crashed `encodeURIComponent`; malformed shard names now
  use UTF-16 unit hex file names.

Broad single-term queries also got faster at query time: the tail-proof loop
used to re-run the full stable-top-k proof after every decoded posting block,
which made tie-heavy doc-ordered terms such as `Paris` spend most of their
latency re-sorting tens of thousands of scored candidates. Failed proofs are
now rescheduled proportionally to the scored-candidate volume
(`topKProofCheckScoresPerBlock`, capped by `topKProofCheckIntervalMax`), which
kept requests/bytes identical and exact top-k at 16/16 while cutting average
cold text latency from 118.1 ms to about 40 ms at 500k and from 252 ms to
about 61 ms at 1M (Paris: 1,235 ms to 221 ms at 1M).

The 500k non-typo cold runtime average was 26.7 requests and 300.5 KB, inside
the +10% request/byte gate against the previous 25.5 request / 301.3 KB
sidecar baseline. The two typo runtime rows stayed at max 3 corrected searches
and max 12 main-term shard lookups.

## Local 50k Run

Build command, reusing the cached 50k JSONL fixture:

```bash
/usr/bin/time -p node scripts/frwiki_fixture.mjs all --limit=50000 --runs=2
```

Latest cold-transfer bench command against that index:

```bash
node scripts/frwiki_fixture.mjs bench --limit=50000 --runs=2
```

The benchmark uses a fresh runtime per query row and resets the fetch meter
after manifest initialization. Cold query rows therefore exclude the one-request
init cost and do not share runtime caches with earlier rows. Warm columns are
still repeated runs inside the same query row.

Result:

```text
Docs indexed:        50,000
Dump pages read:     65,687
Body cap:            6,000 cleaned characters/article
Logical shards:      15,104
Term packs:          8
Index files:         85
Index bytes:         153.0 MB (145.9 MiB)
Manifest/init:       11.6 ms, 1 request, 104.7 KB
Pack tables:         8 term, 5 posting-block, 8 doc, 5 doc-page, 1 doc-value, 1 sorted doc-value, 1 facet, 13 typo
Doc pointer table:   2.0 MB, 41-byte fixed records
Doc ordinal table:   0.1 MB, 2-byte fixed records
Doc page table:      64.1 KB, 1,563 fixed records, 32 docs/page
Doc page packs:      17.1 MB, rfdocpagecols-v1 binary columns
Sorted doc-values:   29.2 KB directories, 0.7 MB packed value pages
Doc layout:          rflocal-doc-v1, 21,558 primary terms
```

Representative cold queries:

```text
Paris:                    44.0 ms, 14 requests,  90.5 KB, packed docs, 1 block / 128 postings
Révolution française:     44.1 ms, 28 requests, 244.5 KB, packed docs, 31 blocks / 3,744 postings
intelligence artificielle: 29.7 ms, 27 requests, 281.7 KB, packed docs, 3 blocks / 257 postings
Victor Hugo:              21.0 ms, 31 requests, 140.7 KB, packed docs, 7 blocks / 728 postings
football:                  9.4 ms, 21 requests,  71.3 KB, packed docs, 1 block / 128 postings
médecine:                 12.5 ms, 24 requests, 122.0 KB, packed docs, 1 block / 128 postings
changement climatique:    37.1 ms, 30 requests, 167.6 KB, packed docs, 60 blocks / 7,472 postings
fromage:                   6.3 ms,  7 requests,  87.7 KB, packed docs, 3 blocks / 285 postings
Québec:                    7.5 ms, 10 requests,  98.1 KB, packed docs, 8 blocks / 913 postings
Napoléon Bonaparte:       14.2 ms, 23 requests, 157.1 KB, packed docs, 3 blocks / 257 postings
typed dates sorted:       12.1 ms,  4 requests,  18.8 KB, sorted doc-value + doc page lane
dense filter browse:       3.2 ms,  3 requests,  11.6 KB, doc-value chunk early stop + doc page lane
multi facet boolean:       6.1 ms, 10 requests,  21.6 KB, sorted doc-value + facet/doc-value checks
```

All rows reported `valid: true`. Every text query also reported
`exactTopKMatch: true` against the exact retrieval path. Broad single-term
queries now use the same block-max top-k scheduler as multi-term queries:
`Paris` matched exact top 10 after decoding 1 of 49 posting blocks,
`football` matched exact top 10 after decoding 1 of 7 blocks, and
`changement climatique` matched exact top 10 after decoding 60 of 71 blocks.
High-df phrase-style rows now batch posting-block frontier refills:
`Révolution française` used 3 posting-block range requests instead of the
previous 20, and `changement climatique` used 4 instead of 27.

Warm repeated text queries were served from the runtime cache with zero
additional network requests and sub-millisecond to low-single-digit millisecond
latency. Broad sorted metadata views now use `rfdocvaluesortdir-v1` directories
and `rfdocvaluesortpage-v1` value pages: the 50k typed date/body-length sort
fetches one value page, scans 2,048 sorted rows, and accepts the first 10
matches. Broad unsorted range browsing keeps document order and stops after the
first matching doc-value chunk, so the result ids stay dense enough to use one
binary doc page.

High-cardinality facet dictionaries are stored with the same range-directory
and pack strategy as terms and documents. The 50k manifest is 104.7 KB; the
large category dictionary lives in `facets/packs/*.bin.gz` and is fetched only when
that facet is selected or a UI asks for its values.

The current index uses `rfdir-v2` directory pages, a dense doc-id-keyed
`rfdocptr-v1` document pointer table, and ZFS-inspired block pointers for every
compressed object. Each pointer records physical length, logical length,
codec/kind metadata, and a SHA-256 checksum that the browser runtime verifies
before decompression. That adds directory/manifest bytes versus an unchecked
format, but it makes range-fetched objects self-verifying and catches stale or
corrupt CDN/object-store responses before
decoding.

Dense doc pointers replace the previous document directory for text results.
The pointer table is keyed directly by original numeric document id, while
document payload packs are still written in locality order derived from each
document's strongest base term and impact score. Dense doc pages add a second
result-payload lane for browse/filter/sort rows: the builder writes compressed
binary column pages of 32 display payloads in original document-id order, and
the runtime uses that lane only when the requested result ids are dense enough
to keep overfetch bounded. The measured rows show that this keeps dense browse
payload requests low without adding an ordinal lookup lane to text top-k rows,
while sparse text results continue to use retrieval-local packed docs.

## Scale Run

The scale command builds isolated fixtures for each requested limit and writes a
combined report to `benchmarks/frwiki/latest/scale/full-dump.json`, with
timestamped history under `benchmarks/frwiki/history/scale/`:

```bash
node scripts/frwiki_fixture.mjs scale --scale-limits=50000,100000 --runs=2
```

Latest scale result:

```text
Docs        Index      Files  Init             Bytes/doc  Text avg        Browse avg      Exact
50,000      145.9 MiB     85  1 req / 104.7 KB  3061 B    21.5 req / 146 KB  5.7 req / 17 KB  10/10
100,000     267.0 MiB    122  1 req / 169.3 KB  2800 B    22.1 req / 172 KB  5.7 req / 22 KB  10/10
```

Selected rows:

```text
Paris:                 50k 14 req /  90.5 KB, 100k 16 req / 101.3 KB
Révolution française:  50k 28 req / 244.5 KB, 100k 28 req / 278.0 KB
typed dates sorted:    50k  4 req /  18.8 KB, 100k  4 req /  24.6 KB
dense filter browse:   50k  3 req /  11.6 KB, 100k  3 req /  11.6 KB
```

The scale result is now strong for both text and metadata retrieval. Text
request counts and transfer grow slowly while exact top-k agreement remains
10/10 at both sizes. The selected high-df `Révolution française` row stays at
3 posting-block fetch groups and 28 total cold requests at both 50k and 100k.
Metadata browse is flat enough for a static browser index:
sorted top-k grows from 18.8 KB to 24.6 KB when the corpus doubles, and dense
unsorted range browse stays at 3 requests / 11.6 KB because it stops after one
matching doc-value chunk and one doc page.

Pack files, directory pages, and directory roots are content-addressed with
24-hex-character SHA-256 name suffixes. The 50k run reported 114,972 exact
compressed objects and no duplicate compressed objects to deduplicate, which is
expected for real article/search shards. The dedup table remains useful for
synthetic or repeated payloads, but the important CDN win here is that every
heavy object can be served as immutable; only the main manifest needs
revalidation.
