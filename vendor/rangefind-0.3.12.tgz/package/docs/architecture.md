# Architecture

Rangefind separates logical retrieval units from physical deployment files.

## Build Output

The package ships one browser entrypoint:

```text
dist/runtime.browser.js
```

That file bundles the query runtime and browser-safe codecs into a single ESM
module. Hosts should import it directly instead of copying `src/*.js`; the
source modules remain the development and Node test surface.

```text
rangefind/
  manifest.json
  segments/
    manifest.json.gz
  doc-values/
    packs/
      0000.<hash>.bin.gz
    sorted/
      bodyLength.<hash>.bin.gz
    sorted-packs/
      0000.<hash>.bin.gz
  facets/
    directory-root.<hash>.bin.gz
    directory-pages/
      0000.<hash>.bin.gz
    packs/
      0000.<hash>.bin.gz
  docs/
    pointers/
      0000.<hash>.bin.gz
    pages/
      0000.<hash>.bin.gz
    page-packs/
      0000.<hash>.bin.gz
    packs/
      0000.<hash>.bin.gz
  terms/
    directory-root.<hash>.bin.gz
    directory-pages/
      0000.<hash>.bin.gz
    block-packs/
      0000.<hash>.bin.gz
    packs/
      0000.<hash>.bin.gz
      0001.<hash>.bin.gz
  authority/
    lexicon-root.<hash>.bin.gz
    hot/
      <hash>.bin.gz
    directory-root.<hash>.bin.gz
    directory-pages/
      0000.<hash>.bin.gz
    packs/
      0000.<hash>.bin.gz
  geo/
    location.<hash>.bin.gz
    point-packs/
      0000.<hash>.bin.gz
```

`manifest.json` is small enough for page initialization. It lists schema,
feature flags, an `object_store` descriptor, default results, compact facet
counts, and pointers to the paged range directories. Full facet dictionaries use
the same range-pack layout as terms and documents, so high-cardinality metadata
does not inflate cold start.

## Object Pointers

New builds use ZFS-inspired immutable object pointers. Every range-packed object
that can be fetched independently is described by the same pointer shape:

```json
{
  "pack": "0000.<hash>.bin.gz",
  "offset": 12345,
  "length": 678,
  "physicalLength": 678,
  "logicalLength": 2048,
  "checksum": { "algorithm": "sha256", "value": "..." }
}
```

Paged directory files use `rfdir-v2`, which stores those pointers next to each
logical key. Doc-id-keyed doc pointer tables, doc-page pointer tables,
doc-value chunks, and external posting blocks embed the same pointer fields in
their owning metadata. The browser verifies the compressed range bytes against
the SHA-256 checksum before decompression, so stale CDN objects, partial uploads,
and corrupt deploys fail before a parser sees invalid bytes. Runtime
verification can be disabled with `createSearch({ verifyChecksums: false })` for
diagnostics, but the default is to verify when the index advertises
`features.checksummedObjects`.

Pack files, directory pages, and directory roots use content-addressed immutable
names. The numeric prefix keeps deterministic pack ordering, while the SHA-256
hash suffix changes whenever the bytes change. Directory pages keep compact
numeric pack indexes and resolve them through a `pack_table`, so filenames are
CDN-safe without bloating every logical entry. Typo correction reuses the main
term directory and posting packs, so hosts do not need to publish a separate
correction sidecar. Hosts can serve every hashed object with long-lived
immutable cache headers; only the main `manifest.json` needs revalidation or
versioned publication.

The pack writer can perform a narrow ZFS-style deduplication pass at build time.
When enabled, it hashes each independently compressed object and reuses the same
pack/offset pointer for exact byte-identical objects. High-volume lanes that do
not benefit from dedupe, such as document payload packs, use append-only writers
that return object pointers without retaining a builder-wide entry map. Dedupe
is intentionally exact only: near-duplicate text or cross-block semantic dedup
would add runtime indirection and extra range fetches, which is usually a bad
trade for a latency-sensitive browser index.

`facets/packs/*.bin.gz` store independently compressed binary facet dictionaries
addressed through `facets/directory-root.<hash>.bin.gz` and
`facets/directory-pages/*.bin.gz`. The runtime lazy-loads a dictionary only when
that facet is selected or an application asks for its values. The small facet
directory manifest is lazy at `facets/manifest.json.gz`, so filtered paths do
not need `manifest.full.json` just to resolve facet codes.

`doc-values/packs/*.bin.gz` store range-addressed column chunks used by filters and
sorting. Keyword facets are encoded as per-document bitsets, so a facet can be
single-value or multi-value. Numeric and date fields are encoded as typed
range/sort values, and booleans use a compact tristate representation for
missing, false, and true. The manifest carries per-chunk summaries, so broad
filter and sort queries can fetch only the involved columns and skip chunks that
cannot match instead of downloading one global code table.

`doc-values/sorted/*.bin.gz` stores a lazy binary directory per numeric/date/
boolean field. Each directory points into `doc-values/sorted-packs/*.bin.gz`, where
`rfdocvaluesortpage-v1` pages keep value-sorted `(value, docId)` rows plus
per-page min/max summaries for every sortable/filterable typed field. Sorted
top-k browse loads the directory for the requested sort field, fetches only the
next value page in sort order, and stops once the requested page is full.
The small sorted-field manifest is lazy at
`doc-values/sorted/manifest.json.gz`, so cold sort paths avoid
`manifest.full.json`.
Unsorted filter browsing keeps document order instead: it walks doc-value
chunks in doc-id order and stops after enough matches, preserving the dense
doc-page payload lane. This gives both value-order pruning for sorted views and
low-request dense browsing for broad filters.

`docs/pointers/*.bin.gz` is a dense fixed-record pointer table keyed directly by
numeric document id. Result fetching no longer walks a generic string directory
or a separate ordinal table for documents. The builder writes document payload
packs in retrieval-local order, and the runtime fetches doc-id pointer records
directly before range-fetching the referenced compressed payloads from
`docs/packs/*.bin.gz`.

`docs/pages/*.bin.gz` is a second dense pointer table keyed by document-id page,
and `docs/page-packs/*.bin.gz` stores `rfdocpagecols-v1` binary column pages in
original document-id order. The format stores the page field list once in the
manifest, writes typed column values for each page, and treats `index` as an
implicit document-id offset. This lane is optimized for browse, filter, and sort
result pages where returned ids are clustered. The runtime estimates page
overfetch before using it; sparse text top-k results stay on the retrieval-local
doc pack lane.

`terms/directory-root.<hash>.bin.gz` is loaded lazily on the first real term
query. It contains page bounds and a compact Bloom filter for adaptive shard
resolution. Only touched `terms/directory-pages/*.bin.gz` files are fetched, and
each page maps logical shard names to checksummed object pointers.

`terms/packs/*.bin.gz` contain many independently compressed posting segments. The
browser requests exactly the byte span it needs and decompresses that one
segment. High-df posting lists can move their posting blocks into
`terms/block-packs/*.bin.gz`; the posting segment then carries term metadata,
block-max scores, filter summaries, and byte ranges for external blocks.
The text top-k runtime schedules a small frontier of the highest-impact active
cursors, then batches external posting-block misses across those cursors before
issuing range requests. Each cursor keeps a contiguous cached posting window and
only refills the next window when the cached run is almost exhausted, so broad
terms behave like dynamic superblocks instead of one range request per logical
block. The same adaptive overfetch planner is used for external posting blocks
and result documents: nearby byte ranges are merged when the extra transfer is
bounded and materially reduces request count.

The builder writes postings into bounded immutable `rfsegment-v1` segment
directories under `_build/segments/`. Each segment contains a compact term
directory and append-only posting rows, so the main indexing pass no longer
builds one global posting run and sorts it at the end. The segment merger reads
term streams with a heap, merges postings per term in doc-id order, and reuses
that stream for prefix statistics, query-bundle df, and final partition
emission.

`segments/manifest.json.gz` stores `rfsegmentmanifest-v1`, a checksummed
summary of the immutable segments that produced the published index. The
builder publishes each segment's term directory and posting row file under
`segments/s*/`, then records file checksums, doc-id ranges, term and posting
counts, field lists, merge fan-in, and merge tier decisions. The runtime can
lazy-load that manifest and use a segment-fanout exact lane that searches
matching terms across published segments, applies the same global-id filters
and sort lanes, and merges the final top-k candidates exactly. The force-merged
posting layout remains the optimized default for block-max tail searches.

Segment flushing is controlled by explicit builder limits. `segmentFlushDocs`
and `segmentFlushBytes` set direct flush thresholds, while
`builderMemoryBudgetBytes` can derive a per-worker byte budget when a direct
byte threshold is not configured. Every segment manifest row records the flush
reason and estimated peak segment memory. If one document alone exceeds the byte
limit, the builder fails early instead of producing an unpredictable oversized
segment.

Segment merging uses an explicit `tiered-log` policy. Segments are ordered by
size, similarly sized batches are merged up to `segmentMergeFanIn`, and
`finalSegmentTargetCount` can request an optional force merge down to a target
count such as `1`. `segmentMergeMaxTempBytes` can block oversized merge batches;
`segmentMergeMaxDirectoryBytes` independently caps the compact term-directory
bytes admitted to a batch because those rows expand into strings and objects
while merging. Blocked tiers are recorded instead of silently exceeding either
budget. The build telemetry and segment manifest record the merge target,
skipped segment count, intermediate bytes, write amplification, and whether a
budget prevented the requested target from being reached.

Term pack assembly uses the same append-only direction. As posting partitions
are compressed into `terms/packs/*.bin.gz`, the builder writes compact binary
directory-entry records into `_build/terms-directory.run`. After immutable pack
renaming, those spooled rows are sorted through bounded chunks and streamed into
the paged term directory. This removes the old dependency on a retained
`packWriter.entries` map for the term directory path and avoids holding all
directory page payloads at once.

When `partitionReducerWorkers` or `builderWorkerCount` enables reducer workers,
posting partitions are represented as byte ranges into the binary reduced-term
spool. The main thread sends workers only partition descriptors: shard name,
byte range, term count, row count, and estimated input bytes. Workers stream
those ranges back from disk, so large posting arrays are not structured-cloned
between heaps and the builder does not duplicate the reduced term stream. A
reducer scheduler accounts active partition bytes with
`partitionReducerInFlightBytes`; if it is unset, the limit is derived from
`builderMemoryBudgetBytes`, or from reducer worker count and pack target size
when no global budget is configured. Workers write term packs and external
posting-block packs into the shared numeric pack directories through atomic
pack-index counters, so posting segment headers can keep stable numeric
block-pack indexes. Worker pack finalization is staggered to avoid simultaneous
completion peaks. Posting-segment objects are emitted as header/body chunks.
Small partitions use fast buffered gzip; partitions at or above
`postingSegmentStreamMinBytes` gzip directly into append-only packs while
hashing the compressed stream, which avoids retaining both a full raw segment
buffer and a full compressed buffer for large partitions. The main thread still
owns final directory assembly, which keeps range lookup deterministic while
moving partition encoding off the main event loop.

Large posting lists whose doc ids are already sorted use impact-bucket ordering
instead of a JavaScript comparator sort when the quantized impact range fits
`postingImpactBucketOrderMaxBuckets`. This keeps impact-ordered block-max output
but turns the common high-df reducer path into linear counting/bucket placement
rather than `O(n log n)` object-array sorting.

Posting segment headers also emit impact-tier block references for high-df
terms. When a term has at least `postingImpactTierMinBlocks` posting blocks, the
builder stores up to `postingImpactTierMaxBlocks` block indexes ordered by
per-block max impact, with tier boundaries for equal-impact groups. The runtime
uses those references to schedule exact Block-Max/doc-range work without sorting
all block metadata during query execution. The planner keeps one task queue per
term and doc-id range, decodes the highest local upper-bound blocks first, scales
the initial batch quantum with the requested top-k, coalesces all selected
term/block pairs through one range-fetch grouping pass, and stops only when the
global upper-bound proof proves top-k completeness.

The first ingestion pass also writes two extra file-backed spools. A
selected-term spool stores each document's final selected scoring terms and
scaled impacts, so query-bundle construction can stream precomputed scoring
signals instead of re-reading and re-tokenizing the JSONL corpus. Document
payloads are stored in both compressed and raw spools: retrieval-local doc packs
reuse the compressed payload spool, while dense doc-page construction reads the
raw spool directly and avoids a build-time gzip/decompress loop.

Field rows are captured in the same scan pass through the typed
`rf-build-code-store-v1` spool. The build wraps that store as
`rffieldrows-v1`, and query bundles, doc-value chunks, sorted doc-value pages,
and filter bitmaps now consume the same typed row source. Numeric, date,
boolean, single facet, and multi-facet rows are therefore extracted once during
scan instead of re-reading the source corpus for every downstream artifact.
Reducer workers use `codeStoreWorkerCacheChunks` to cap their file-backed
field-row caches independently from the main build process. When it is `0`, the
builder chooses enough chunks to cover the corpus up to
`codeStoreWorkerMaxAutoCacheChunks`, which avoids repeated random re-reads on
large high-df posting lists while still bounding worker memory.

The final pack writer still emits immutable range-pack objects in deterministic
term order, and externalizes large posting blocks into `terms/block-packs/`.
Every build manifest includes `build.format = "rfbuildtelemetry-v1"` with
sampled per-phase memory peaks, CPU user/system time, disk byte deltas, segment
counters, and reduce/merge worker timing so large-corpus regressions can be
compared from the emitted index alone. When `buildProgressLogMs` is non-zero,
the same telemetry layer writes live phase start, heartbeat, and completion
lines to stderr with elapsed time, RSS, heap, temp bytes, pack bytes, and
sidecar bytes. This keeps long scan, reduce, segment-publish, and sidecar phases
observable before the final telemetry file exists.

Authority fields use the same file-backed run/reduce pattern as postings. Each
configured title, entity-name, slug, or alias value emits surface-exact,
folded-exact, and token authority keys into temporary run files. The reducer
writes `rfauth-v2` shards into immutable `authority/packs/*.bin.gz` objects and a
paged range directory. Authority has its own shard budget
(`authorityTargetShardRows`) and deeper max shard depth
(`authorityMaxShardDepth`) and smaller directory pages
(`authorityDirectoryPageBytes`) because label lookups are point reads; they
should not inherit the larger posting-list segment and directory budgets used by
normal posting segments.
The browser probes the surface-exact key first, which keeps accent-sensitive
matches such as `Paris` and `Pâris` distinct. It only falls back to folded or
token keys when the stronger key cannot rescue the first page. Authority scores
are additive with the normal text score, but the sidecar is independent from the
main posting lists, so projects can add canonical-label quality without
bloating every text query.

Document packs contain independently compressed result-display payloads written
in retrieval-local order. The builder spools compressed payloads to disk during
ingestion, computes a compact locality record from each document's strongest
base terms, then assembles final packs by primary term and impact. The dense
pointer table preserves direct lookup by original document id. Payloads contain
only configured display fields, not necessarily the full indexed text. A display
object can set `maxChars` to cap a returned string field while the corresponding
indexed field remains uncapped for scoring. This keeps random result-fetch
traffic bounded for long documents and avoids over-fetching a whole JSON chunk
for one result. The same display payloads are also written into fixed-size doc
pages for dense metadata browsing; that duplicates payload bytes, but it removes
random pointer fan-out when a result page is contiguous enough.

## Retrieval Model

The builder computes weighted field term frequencies, normalizes field length,
then applies BM25F-style saturation before writing impact scores. Phrase terms
can be emitted for fields such as titles.

Each posting list is stored in impact order and split into blocks with max-impact
metadata. The runtime uses those block maxima for single-term and multi-term
top-k queries: it decodes the highest-potential blocks first and can stop once
no remaining block can change the requested top results.

For high-df terms, decoded blocks are fetched from `terms/block-packs/*.bin.gz`
only when the block-max scheduler chooses them. The runtime prefetches a small
adjacent block window, so medium lists behave like range-addressed superblocks
while very large lists can still avoid downloading their full posting payload.
Very high-cardinality facets are omitted from posting-block summaries by
default; exact per-document filtering still uses doc-value chunks, while block
filters keep only compact summaries that are worth shipping on every term block.

For no-query metadata views, the runtime now uses doc-value pruning instead of
materializing every candidate chunk. Sort requests use the sorted doc-value tree
for the sort field and evaluate filters with page summaries before touching
per-document chunks. Filter-only browse requests use doc-id chunk summaries and
early stop as soon as `offset + size` matching documents are found, which keeps
the returned ids dense enough for binary doc pages.

## Geo Point Trees

Geo fields configured as `{ "name": "location", "latPath": "lat", "lonPath":
"lon" }` produce a Lucene-`LatLonPoint`-style static point index adapted to
range requests:

- Coordinates are stored as fixed-precision E7 integers (about 1 cm), exactly
  like Lucene's encoding.
- The builder bulk-loads a KD tree by recursively splitting points on the
  physically wider dimension (longitude spans shrink by cos(latitude)) until
  leaves hold `geoLeafSize` points (default 512). Leaves are written in
  depth-first order so spatially adjacent leaves stay adjacent inside
  `geo/point-packs/*.bin.gz` and coalesce into few range requests.
- Each leaf page stores its bounding box plus delta-encoded fixed-width
  lat/lon/doc columns, individually gzipped and checksummed like every other
  range object.
- A gzipped tree root (`geo/<field>.<hash>.bin.gz`) is loaded lazily on the
  first geo query. Small trees list every leaf inline; large trees are
  two-level: the root lists branch entries (bbox, point count, object pointer)
  whose leaf tables live in lazily fetched branch pages inside the same point
  packs. A branch page covers `geoBranchLeaves` leaves (default 256), so the
  cold root stays a few KB at any point count and a query only downloads the
  branch pages its constraint intersects.

Every geo field also registers hidden `location.lat`/`location.lon` double
doc-values. Bounding-box constraints rewrite into numeric range filters over
those columns, so text-plus-geo queries inherit doc-value chunk pruning,
sorted-page summaries, and posting-block range pruning without new machinery.

Query lanes:

- **Browse** (`q: ""` with `geo.box` or `geo.near`): intersecting leaves are
  visited in pack order with adaptive batching; leaves fully contained in the
  query skip per-point verification; radius queries verify with Haversine.
- **Nearest** (`geo.sort: "distance"`): best-first traversal by exact
  point-to-cell distance with a top-k boundary proof — traversal stops when no
  unvisited leaf can beat the current k-th distance, which typically touches
  only 1-3 leaves.
- **Text plus geo**: when the geo constraint covers at most
  `geoTextMaxCandidatePoints` points (default 100k), the runtime resolves the
  matching doc-id set from the tree first and filters postings against it;
  otherwise it falls back to per-document doc-value verification. Distance
  boost (`geo.boost`) applies Lucene's `weight * pivot / (pivot + distance)`
  shape to the returned page window.
- **Text plus distance sort** (`q` with `geo.sort: "distance"`): the runtime
  resolves the exact text match set from postings (same minShouldMatch rule
  as `count()`, bounded by `geoTextSortMaxDf`, default 200k postings), then
  the nearest lane orders it with the usual early-stop proof — "closest
  bakeries first" is exact.

Leaf and branch entries also carry posting-block-style filter summaries
(facet words, numeric min/max, boolean bounds), so facet/boolean/numeric
filters prune cells that provably contain no match before any page is
fetched — a sparse-category nearest query touches only the cells where the
category exists.

Point-to-box minimum and maximum spherical distances are exact (including
antimeridian wrap, facing-away meridians, and antipodal interiors), so radius
pruning and containment proofs never drop a matching document.

## Unified Authority Autocomplete

`suggest` config fields feed an autocomplete namespace inside the authority
run/reduce pipeline. Diacritic-folded, punctuation-collapsed full surfaces and
token suffixes are written directly to bounded external runs; no scan-wide map
of unique surfaces exists. The authority reducer aggregates document counts
and maximum explicit weights while writing the same `authority/packs/*.bin.gz`
objects used for canonical-label rescue.

Autocomplete entries in `rfauth-v2` store display text, count, and final weight
without document rows. A compact `rflexicon-v1` root records only each relevant
authority shard's maximum composite rank and entry count. Per-character hot lists are
small immutable objects under `authority/hot/`, fetched only for a
single-character query; they do not inflate every cold prefix request.

Query execution remains exact top-k:

- A prefix selects authority leaf shards by their trie prefixes, including
  recursively split hot shards.
- Shards are visited best-first by `maxRank`; traversal stops only when the
  current k-th result strictly outranks every unvisited shard maximum.
- Results are deduplicated by display text. Weighted indexes rank by
  `weightPath`, while unweighted indexes prefer direct surface prefixes before
  token suffixes; popularity, concise display text, and normalized key provide
  deterministic lower-order signals.
- Single-character prefixes use their precomputed authority hot list, avoiding
  the widest shard traversal.

Old `rfauth-v1` title-only indexes remain readable through the bounded
lexicographic fallback, but new builders never emit `suggest/` artifacts or a
`manifest.suggest` branch.

## Vector Index

`vectors` config fields build a range-addressed IVF index for cosine
similarity over embeddings supplied in the JSONL (float arrays or base64
float32). Vectors are L2-normalized, dimension-permuted variance-descending
(a permutation learned from the training sample preserves dot products and
makes the leading dimensions the most informative), and int8-quantized with
one scale per vector.

```text
vectors/
  <field>.<hash>.bin.gz        # root: int8 centroids, cluster pointers,
                               # dimension permutation, refine layout
  <field>/packs/               # cluster pages: doc ids, refine ordinals,
    0000.<hash>.bin.gz         # scales, int8 coarse-dim rows (gzip members)
  <field>/refine-packs/        # fixed-width full-dim int8 rows addressed by
    0000.<hash>.bin.gz         # ordinal * rowBytes (raw, random access)
```

Query execution (`vectorSearch` / hybrid `search({ q, vector })`):

1. Score the query against int8 centroids from the root (fetched once per
   session) and pick the top `nprobe` clusters.
2. Fetch those cluster pages and rank candidates on the coarse dimension
   prefix (default dims/4).
3. Re-score the best `k × refineFactor` candidates against full-dimension
   int8 rows fetched from the refine store through coalesced range requests,
   and return the exact-int8 top k.
4. Hybrid queries run the text lane in parallel and fuse with reciprocal
   rank fusion; filters verify on both lanes.

The builder streams spooled vectors twice (sample/train, then
quantize/assign/pack), so embeddings never sit in memory; 100k × 256-dim
vectors index in ~2 s.

## Why Custom Binary

The hot path is term-keyed inverted-list lookup, not columnar analytics. The
custom binary format keeps shard directories, block metadata, and postings in
the order the runtime reads them. Parquet or Arrow remain useful for ingestion
and benchmark artifacts, but not for the current browser posting-list hot path.

## Static Range Packs

Using thousands of tiny static files is expensive for deployment and filesystem
metadata. Using one giant compressed file prevents independent decompression.
Rangefind keeps each logical shard independently compressed, then concatenates
those compressed members into larger packs.
